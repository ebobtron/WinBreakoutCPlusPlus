#ifndef __RESOURCE_H_INCLUDED__
#define __RESOURCE_H_INCLUDED__

#include "version.h"

#define IDI_MYICON      101

#define ID_FILE_EXIT    4001
#define IDR_MYMENU      102
#define IDI_MYICON2      201
#define ID_FILE_EXIT2    9001
#define ID_STUFF_GO     9002

#define IDW_MYBALLSOUND 2000
#define IDW_MYBUZSOUND 2001
#define IDR_VERSION 1

#endif // __RESOURCE_H_INCLUDED__
