# WinBreakoutCPlusPlus
a Windows solution for the game Breakout
inspired by the Stanford Portable Library (SPL) version of Breakout used in CS50x from edX.org

Additional information http://winbreakout.freehostia.com/

